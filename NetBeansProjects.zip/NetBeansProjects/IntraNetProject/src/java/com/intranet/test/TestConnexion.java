package com.intranet.test;

import com.intranet.config.DBConnection;
import java.sql.Connection;

public class TestConnexion {
    public static void main(String[] args) {
        // AJOUTE CECI (Demande à ton responsable réseau les infos de proxy)
        System.setProperty("http.proxyHost", "proxy.ecole.com"); // À remplacer
        System.setProperty("http.proxyPort", "8080");            // À remplacer
        System.setProperty("https.proxyHost", "proxy.ecole.com");
        System.setProperty("https.proxyPort", "8080");
        try {
            Connection conn = DBConnection.getConnection();
            if (conn != null) {
                System.out.println("CONNEXION RÉUSSIE !");
                conn.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ÉCHEC DE LA CONNEXION : " + e.getMessage());
        }
    }
}
