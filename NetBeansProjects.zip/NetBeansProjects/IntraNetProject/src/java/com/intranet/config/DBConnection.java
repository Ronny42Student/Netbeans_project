package com.intranet.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:postgresql://db.voltrcjmqncvicaafhmm.supabase.co:6543/postgres?sslmode=require";

    private static final String USER = "postgres"; 
    
    private static final String PASS = "Ronnychristophe0111";

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
